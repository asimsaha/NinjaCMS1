﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NinjaCMS.Model
{
    public class ModelTemplate
    {
        //Model Properties
        //@ModelProperties
    }
}